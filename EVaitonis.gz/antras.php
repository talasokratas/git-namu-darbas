<?php echo "prisijunkite"; 
      echo "antro failo redagavimas ir commitas";
      echo "redagavimas po merdzinimo";